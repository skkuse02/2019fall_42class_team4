# 2019fall_42class_team4

# Review Revolution

![](./docs/photo/logo.png)

### 저희는 **신개념 사용자 리뷰 비교,분석 서비스 시스템 in 웹 쇼핑몰**을 만들고 있습니다.

## **Team Member**

## - 윤성경
## - 정창호
## - 유종현
## - 김진태

### 진행상황 
### - design specification 완료 (2019/11/12)
### - design specification 4차 checkpoint : Testing Plan, State Diagram, Package Diagram 보완 (2019/11/12)
### - design specification 3차 checkpoint : Protocol, Database Design 작성 (2019/11/09)
### - design specification 2차 checkpoint : preface, introduction, testing plan, development plan outline 작성 (2019/11/08)
### - design specification 1차 checkpoint : System architecture overall, frontend, backend 작성 (2019/11/06)
### - requirement 완료 (2019/11/03)
### - requirement 4차 checkpoint : 전체 프로젝트 확인, 비교 및 feedback (2019/11/03) 
### - requirement 3차 checkpoint : appendix 전까지 (2019/11/03)
### - requirement 2차 checkpoint : system requirement까지 (2019/10/31)
### - requirement 1차 checkpoint : user requirement까지 (2019/10/30)
### - proposal 마지막 수정 (2019/10/19)
### - proposal 완료 (2019/10/11)
